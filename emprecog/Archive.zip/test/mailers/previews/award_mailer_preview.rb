# Preview all emails at http://localhost:3000/rails/mailers/award_mailer
class AwardMailerPreview < ActionMailer::Preview

end
