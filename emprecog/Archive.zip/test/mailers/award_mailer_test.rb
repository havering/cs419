require 'test_helper'

class AwardMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
