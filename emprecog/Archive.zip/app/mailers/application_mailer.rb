class ApplicationMailer < ActionMailer::Base
  default from: 'ohaverd@oregonstate.edu'
  #layout 'award_mailer'
end
